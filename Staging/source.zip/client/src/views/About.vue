<!-- Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved. -->
<!-- SPDX-License-Identifier: MIT-0 -->

<template>
  <div class="about">
    <h3>Frontend layer demo</h3>
    <h4>This code is written in Vue.js</h4>
    
  </div>
</template>

<style scoped>

h3, h4, p, a {
  text-shadow: gray;
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  color: white;
  text-align: center;
  padding: 10px;
}

.about {
  padding: 60px;
}

</style>
